const path = require('path');
const fs = require('fs');
const { Low } = require('lowdb');
const { JSONFile } = require('lowdb/node');

const file = path.join(__dirname, 'data', 'db.json');
fs.mkdirSync(path.dirname(file), { recursive: true });

const adapter = new JSONFile(file);
const defaultData = { users: [], activities: [] };

const db = new Low(adapter, defaultData);

async function init() {
  await db.read();
  db.data = db.data || defaultData;
  await db.write();
  console.log('lowdb initialized at', file);
}

async function createUser(username, passwordHash, displayName) {
  await db.read();
  const id = db.data.users.length ? (db.data.users[db.data.users.length - 1].id + 1) : 1;
  const user = { id, username, password: passwordHash, displayName };
  db.data.users.push(user);
  await db.write();
  return user;
}

async function getUserByUsername(username) {
  await db.read();
  return db.data.users.find(u => u.username === username);
}

async function getUserById(id) {
  await db.read();
  return db.data.users.find(u => u.id === id);
}

async function createActivity(userId, { type = 'generic', duration = 0, steps = 0, calories = 0, notes = '' }) {
  await db.read();
  const id = db.data.activities.length ? (db.data.activities[db.data.activities.length - 1].id + 1) : 1;
  const timestamp = Date.now();
  const act = { id, userId, type, duration, steps, calories, timestamp, notes };
  db.data.activities.push(act);
  await db.write();
  return act;
}

async function getActivitiesForUser(userId) {
  await db.read();
  return (db.data.activities || []).filter(a => a.userId === userId).sort((a, b) => b.timestamp - a.timestamp);
}

module.exports = {
  init,
  createUser,
  getUserByUsername,
  getUserById,
  createActivity,
  getActivitiesForUser
};
